import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ClientBody from "./ClientBody";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ShipSync - แพลตฟอร์มรวมขนส่งอัจฉริยะ",
  description: "ระบบจัดการขนส่งออนไลน์อัจฉริยะ ที่ดีที่สุดสำหรับธุรกิจของคุณ",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="th" className={`${geistSans.variable} ${geistMono.variable}`}>
      <body suppressHydrationWarning className="antialiased min-h-screen">
        <ClientBody>{children}</ClientBody>
      </body>
    </html>
  );
}
