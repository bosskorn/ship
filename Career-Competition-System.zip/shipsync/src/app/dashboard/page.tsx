"use client";

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import {
  BarChart3,
  Box,
  CreditCard,
  DollarSign,
  Heart,
  HelpCircle,
  Plus,
  Star,
  TrendingUp,
  User,
  AlertTriangle,
} from "lucide-react";

export default function DashboardPage() {
  const [chartType, setChartType] = useState<'shippings' | 'credits'>('shippings');
  const [startDate, setStartDate] = useState('2025-05-11');
  const [endDate, setEndDate] = useState('2025-05-21');

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">แดชบอร์ด</h1>
        <Button size="sm" variant="outline">
          <RefreshCcw className="mr-2 h-4 w-4" /> รีเฟรช
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-6 lg:grid-cols-12 gap-6">
        {/* Welcome Card */}
        <Card className="col-span-1 md:col-span-3 lg:col-span-4">
          <CardContent className="pt-6">
            <div className="flex items-start justify-between">
              <div>
                <h5 className="font-semibold text-lg">ยินดีต้อนรับ 🎉 กรธนภัทร นาคคงคำ!</h5>
                <p className="text-sm text-muted-foreground mt-1">
                  ค่าเฉลี่ยเริ่มต้น <strong className="text-green-600">49.42</strong> บาท / รายการ
                </p>
                <p className="text-sm text-muted-foreground">คุณมีคะแนนสะสมอยู่ทั้งหมด</p>
                <h3 className="text-xl font-bold mt-2">48.00 คะแนน</h3>
                <Button className="mt-2" size="sm">
                  สร้างรายการจัดส่ง
                </Button>
              </div>
              <img
                src="/images/badge.svg"
                alt="Medal"
                className="w-24 h-24"
              />
            </div>
          </CardContent>
        </Card>

        {/* Stat Cards */}
        <div className="col-span-1 md:col-span-3 lg:col-span-4 grid grid-cols-2 gap-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="rounded-full p-2 bg-yellow-100">
                  <TrendingUp className="h-5 w-5 text-yellow-600" />
                </div>
                <h3 className="text-xl font-bold">15</h3>
              </div>
              <p className="text-sm text-muted-foreground text-right mt-2">รอจัดส่ง</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="rounded-full p-2 bg-green-100">
                  <Box className="h-5 w-5 text-green-600" />
                </div>
                <h3 className="text-xl font-bold">254</h3>
              </div>
              <p className="text-sm text-muted-foreground text-right mt-2">ส่งสำเร็จ</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="rounded-full p-2 bg-blue-100">
                  <User className="h-5 w-5 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold">32</h3>
              </div>
              <p className="text-sm text-muted-foreground text-right mt-2">ลูกค้า</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-start">
                <div className="rounded-full p-2 bg-blue-100">
                  <DollarSign className="h-5 w-5 text-blue-600" />
                </div>
                <h3 className="text-xl font-bold">12,500</h3>
              </div>
              <p className="text-sm text-muted-foreground text-right mt-2">COD (บาท)</p>
            </CardContent>
          </Card>
        </div>

        {/* News Card */}
        <Card className="col-span-1 md:col-span-3 lg:col-span-4 border-blue-500 border-2 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between py-2">
            <CardTitle className="text-white bg-blue-500 px-4 py-1 rounded-full text-sm">
              ข่าวสารใหม่
            </CardTitle>
            <a href="/news" className="text-blue-500 hover:underline text-sm font-medium">ทั้งหมด &gt;</a>
          </CardHeader>
          <CardContent className="p-0">
            <div className="aspect-[16/9] overflow-hidden">
              <img
                src="https://placehold.co/800x450/2563eb/FFFFFF/png?text=ShipSync+News"
                alt="News Banner"
                className="w-full h-full object-cover"
              />
            </div>
          </CardContent>
        </Card>

        {/* Promotion Card */}
        <Card className="col-span-1 md:col-span-3 lg:col-span-4 border-red-500 border-2 shadow-lg">
          <CardHeader className="flex flex-row items-center justify-between py-2">
            <CardTitle className="text-white bg-red-500 px-4 py-1 rounded-full text-sm">
              โปรโมชั่นตอนนี้
            </CardTitle>
            <a href="/promotions" className="text-red-500 hover:underline text-sm font-medium">ทั้งหมด &gt;</a>
          </CardHeader>
          <CardContent className="p-0">
            <div className="aspect-[16/9] overflow-hidden">
              <img
                src="https://placehold.co/800x450/ef4444/FFFFFF/png?text=ShipSync+Promotion"
                alt="Promotion Banner"
                className="w-full h-full object-cover"
              />
            </div>
          </CardContent>
        </Card>

        {/* Chart Card */}
        <Card className="col-span-1 md:col-span-6 lg:col-span-8">
          <CardHeader className="flex flex-row items-center px-6 py-4">
            <div className="flex items-center space-x-2">
              <Button
                variant={chartType === 'shippings' ? 'default' : 'outline'}
                onClick={() => setChartType('shippings')}
                size="sm"
              >
                ยอดขนส่ง
              </Button>
              <Button
                variant={chartType === 'credits' ? 'default' : 'outline'}
                onClick={() => setChartType('credits')}
                size="sm"
              >
                ค่าขนส่ง
              </Button>
            </div>
            <div className="flex items-center ml-auto space-x-2">
              <input
                type="date"
                className="px-2 py-1 border rounded text-sm"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
              <span className="text-sm">ถึง</span>
              <input
                type="date"
                className="px-2 py-1 border rounded text-sm"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="px-6 pb-6">
            <div className="h-[300px] flex items-center justify-center bg-slate-50 rounded-md">
              <div className="text-center">
                <BarChart3 className="h-16 w-16 text-slate-300 mx-auto mb-2" />
                <h3 className="text-lg font-medium text-slate-600">กราฟ{chartType === 'shippings' ? 'ยอดขนส่ง' : 'ค่าขนส่ง'}</h3>
                <p className="text-sm text-slate-400">ข้อมูลจาก {startDate} ถึง {endDate}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Top Shipping Card */}
        <Card className="col-span-1 md:col-span-3 lg:col-span-4">
          <CardHeader>
            <CardTitle className="text-lg">10 จังหวัดส่งของมากที่สุด</CardTitle>
            <p className="text-xs text-muted-foreground">** ข้อมูลเป็นของเดือนล่าสุด</p>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {Array.from({ length: 5 }).map((_, index) => (
                <li key={index} className="flex justify-between items-center">
                  <span className="text-sm">กรุงเทพมหานคร {index + 1}</span>
                  <Badge variant="secondary">{120 - (index * 15)}</Badge>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      {/* Recent Notifications */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center">
            <Bell className="mr-2 h-5 w-5" />
            การแจ้งเตือนล่าสุด
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-blue-500 mt-1 flex-shrink-0" />
              <div>
                <div className="flex justify-between">
                  <h4 className="font-medium text-blue-600">SPX Express ขออนุญาตแจ้งเรื่องรถเข้ารับพัสดุ</h4>
                  <span className="text-sm text-gray-500">27 วันที่แล้ว</span>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  SPX Express ขออนุญาตแจ้งเรื่องรถเข้ารับพัสดุในพื้นที่ที่เข้ารับไม่สำเร็จภายในวันนะคะ...
                </p>
              </div>
            </div>
            <Separator />
            <div className="flex gap-3">
              <AlertTriangle className="h-5 w-5 text-blue-500 mt-1 flex-shrink-0" />
              <div>
                <div className="flex justify-between">
                  <h4 className="font-medium text-blue-600">กรณีที่ SPX Express ไม่สามารถส่งคืนพัสดุ</h4>
                  <span className="text-sm text-gray-500">1 เดือนที่แล้ว</span>
                </div>
                <p className="text-sm text-gray-600 mt-1">
                  ประกาศ มีผล 16 เมษายน 2025 เป็นต้นไป ในกรณีที่ SPX Express ไม่สามารถส่งคืนพัสดุ...
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* New Features Highlight */}
      <Card className="bg-gradient-to-r from-blue-50 to-green-50">
        <CardHeader>
          <CardTitle className="flex items-center text-lg text-blue-700">
            <Sparkles className="mr-2 h-5 w-5" />
            ฟีเจอร์ใหม่ใน ShipSync
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-lg shadow">
              <div className="flex items-center mb-2">
                <Brain className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="font-medium">AI แนะนำขนส่งอัจฉริยะ</h3>
              </div>
              <p className="text-sm text-gray-600">
                ระบบ AI ที่วิเคราะห์ราคาและเวลาจัดส่งของแต่ละขนส่ง เพื่อแนะนำตัวเลือกที่ดีที่สุดสำหรับคุณ
              </p>
              <Button size="sm" variant="outline" className="mt-2">ลองใช้งาน</Button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow">
              <div className="flex items-center mb-2">
                <BarChart3 className="h-5 w-5 text-green-500 mr-2" />
                <h3 className="font-medium">วิเคราะห์ต้นทุนขนส่งเชิงลึก</h3>
              </div>
              <p className="text-sm text-gray-600">
                ดูรายงานและวิเคราะห์ต้นทุนการขนส่งเชิงลึก เพื่อช่วยลดต้นทุนและเพิ่มประสิทธิภาพ
              </p>
              <Button size="sm" variant="outline" className="mt-2">เข้าชมรายงาน</Button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow">
              <div className="flex items-center mb-2">
                <SplitSquareVertical className="h-5 w-5 text-purple-500 mr-2" />
                <h3 className="font-medium">เปรียบเทียบประสิทธิภาพขนส่ง</h3>
              </div>
              <p className="text-sm text-gray-600">
                เปรียบเทียบประสิทธิภาพของแต่ละบริษัทขนส่ง ทั้งด้านราคา เวลา และความพึงพอใจ
              </p>
              <Button size="sm" variant="outline" className="mt-2">เปรียบเทียบตอนนี้</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// เพิ่ม icons ที่ยังไม่ได้ import
import {
  Bell,
  Brain,
  RefreshCcw,
  Sparkles,
  SplitSquareVertical
} from "lucide-react";
