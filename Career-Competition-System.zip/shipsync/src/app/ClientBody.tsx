"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";

// จะสร้างคอมโพเนนต์ Sidebar และ Navbar ต่อไป
import Sidebar from "@/components/layout/sidebar";
import Navbar from "@/components/layout/navbar";

export default function ClientBody({
  children,
}: {
  children: React.ReactNode;
}) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const pathname = usePathname();

  // ตรวจสอบว่ากำลังอยู่ที่หน้า Login/Register หรือไม่
  const isAuthPage = pathname === "/login" || pathname === "/register";

  // Remove any extension-added classes during hydration
  useEffect(() => {
    // This runs only on the client after hydration
    document.body.className = "antialiased";
  }, []);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  // ถ้าเป็นหน้า Login/Register ให้แสดงเฉพาะ children
  if (isAuthPage) {
    return <main className="antialiased">{children}</main>;
  }

  return (
    <div className="flex h-screen bg-slate-50">
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} />

      {/* Main Content */}
      <div className="flex flex-col flex-1 overflow-hidden">
        <Navbar toggleSidebar={toggleSidebar} />
        <main className="flex-1 overflow-y-auto p-4">
          {children}
        </main>
      </div>
    </div>
  );
}
