"use client";

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Bell,
  CreditCard,
  HelpCircle,
  LogOut,
  Menu,
  MessageSquare,
  Settings,
  User,
  LifeBuoy,
  BookOpen,
  Share2,
  Lock,
  RefreshCcw,
  Moon,
  AlertTriangle,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useState } from "react";
import { Separator } from "@/components/ui/separator";

interface NavbarProps {
  toggleSidebar: () => void;
}

export default function Navbar({ toggleSidebar }: NavbarProps) {
  const [notificationCount, setNotificationCount] = useState(5);
  const [balance, setBalance] = useState(-579.25);

  return (
    <header className="h-16 bg-white border-b flex items-center px-4 justify-between sticky top-0 z-10">
      {/* Left side */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={toggleSidebar}>
          <Menu className="h-6 w-6" />
        </Button>

        <div className="flex gap-2">
          <Button size="sm" variant="ghost" className="hidden md:flex">
            <img width="35" src="/icons/wait_light.png" alt="รอจัดส่ง" className="mr-2" />
            รอจัดส่ง
          </Button>
          <Button size="sm" variant="ghost" className="hidden md:flex">
            <img width="35" src="/icons/shipping_light.png" alt="อยู่ระหว่างจัดส่ง" className="mr-2" />
            อยู่ระหว่างจัดส่ง
          </Button>
          <Button size="sm" variant="ghost" className="hidden md:flex">
            <img width="35" src="/icons/shipped_light.png" alt="จัดส่งแล้ว" className="mr-2" />
            จัดส่งแล้ว
          </Button>
          <Button size="sm" variant="ghost" className="hidden md:flex">
            <img width="35" src="/icons/return_pack.png" alt="พัสดุมีปัญหา / ตีกลับ" className="mr-2" />
            พัสดุมีปัญหา / ตีกลับ
          </Button>
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-4">
        {/* Credit Balance */}
        <div className="hidden md:flex items-center mr-4 cursor-pointer hover:bg-gray-100 py-1 px-2 rounded">
          <span className={balance < 0 ? "text-red-500" : "text-green-500"}>
            เครดิตคงเหลือ: {new Intl.NumberFormat('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Math.abs(balance))}
            บาท
          </span>
        </div>

        {/* Language Selector */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm" className="flex items-center gap-1">
              <span className="fi fi-th mr-1"></span>
              <span>TH</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="cursor-pointer">
              <span className="fi fi-th mr-2"></span> TH
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <span className="fi fi-us mr-2"></span> EN
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Notifications */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5" />
              {notificationCount > 0 && (
                <Badge variant="destructive" className="absolute -top-1 -right-1 px-1.5 py-0.5 min-w-[18px] min-h-[18px] flex items-center justify-center">
                  {notificationCount}
                </Badge>
              )}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[380px]">
            <DropdownMenuLabel className="flex justify-between">
              <span>การแจ้งเตือน</span>
              <Button variant="ghost" size="sm" onClick={() => setNotificationCount(0)}>
                อ่านแล้วทั้งหมด
              </Button>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <div className="max-h-[400px] overflow-y-auto">
              <DropdownMenuItem className="flex items-start gap-2 py-2 cursor-pointer">
                <AlertTriangle className="h-4 w-4 text-blue-500 mt-1 flex-shrink-0" />
                <div className="flex flex-col">
                  <div className="flex justify-between w-full">
                    <span className="font-medium text-blue-500">SPX Express ขออนุญาตแจ้งเรื่องรถเข้ารับพัสดุ</span>
                    <span className="text-xs text-gray-500">27 วันที่แล้ว</span>
                  </div>
                  <span className="text-xs text-gray-600 line-clamp-2">
                    SPX Express ขออนุญาตแจ้งเรื่องรถเข้ารับพัสดุในพื้นที่ที่เข้ารับไม่สำเร็จภายในวันนะคะ...
                  </span>
                </div>
              </DropdownMenuItem>
              <Separator />
              <DropdownMenuItem className="flex items-start gap-2 py-2 cursor-pointer">
                <AlertTriangle className="h-4 w-4 text-blue-500 mt-1 flex-shrink-0" />
                <div className="flex flex-col">
                  <div className="flex justify-between w-full">
                    <span className="font-medium text-blue-500">กรณีที่ SPX Express ไม่สามารถส่งคืนพัสดุ</span>
                    <span className="text-xs text-gray-500">1 เดือนที่แล้ว</span>
                  </div>
                  <span className="text-xs text-gray-600 line-clamp-2">
                    ประกาศ มีผล 16 เมษายน 2025 เป็นต้นไป ในกรณีที่ SPX Express ไม่สามารถส่งคืนพัสดุไปยังผู้ขายได้...
                  </span>
                </div>
              </DropdownMenuItem>
            </div>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer justify-center">
              <Button variant="outline" size="sm" className="w-full">ดูการแจ้งเตือนทั้งหมด</Button>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* User Profile */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-9 w-9 rounded-full">
              <Avatar>
                <AvatarImage src="/avatar.jpg" alt="User Avatar" />
                <AvatarFallback>SS</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">HOME WORD</p>
                <p className="text-xs leading-none text-muted-foreground">
                  homeword@example.com
                </p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer">
              <CreditCard className="mr-2 h-4 w-4" />
              <span>โปรโมชั่นตอนนี้</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <User className="mr-2 h-4 w-4" />
              <span>ข้อมูลส่วนตัว</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Share2 className="mr-2 h-4 w-4" />
              <span>ระบบแนะนำเพื่อน</span>
              <Badge variant="outline" className="ml-2 bg-red-500 text-white border-none">NEW</Badge>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Lock className="mr-2 h-4 w-4" />
              <span>เปลี่ยนรหัสผ่าน</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer">
              <RefreshCcw className="mr-2 h-4 w-4" />
              <span>เวอร์ชั่นอัพเดต</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Moon className="mr-2 h-4 w-4" />
              <span>โหมดกลางคืน</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <Settings className="mr-2 h-4 w-4" />
              <span>ตั้งค่าระบบ</span>
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer">
              <User className="mr-2 h-4 w-4" />
              <span>จัดการพนักงาน</span>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="cursor-pointer">
              <LogOut className="mr-2 h-4 w-4" />
              <span>ออกจากระบบ</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
