"use client";

import { cn } from "@/lib/utils";
import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Box,
  BarChart3,
  Package,
  Truck,
  CreditCard,
  MapPin,
  FileText,
  Users,
  ShoppingBag,
  Settings,
  HelpCircle,
  Warehouse,
  Folder,
  Briefcase,
  MessageCircle,
  Gift,
  List,
  Info,
  BookOpen,
  Headphones,
  Edit
} from "lucide-react";

// ข้อมูลเมนูหลัก
const mainMenuItems = [
  {
    title: "ผลการดำเนินงาน",
    icon: <BarChart3 size={20} />,
    href: "/dashboard",
  },
  {
    title: "รายการพัสดุ",
    icon: <Package size={20} />,
    href: "/shipments",
    submenu: [
      { title: "สร้างรายการ", href: "/shipments/create" },
      { title: "เลือกขนส่งแล้ว", href: "/shipments/selected" },
      { title: "รอเลือกขนส่ง", href: "/shipments/pending" },
      { title: "จัดส่งพัสดุ", href: "/shipments/checkout" },
      { title: "พิมพ์ใบปะหน้า", href: "/shipments/print" },
      { title: "ส่งด่วน", href: "/shipments/express" },
      { title: "โต้แย้งขนาดน้ำหนัก", href: "/shipments/dispute" },
    ],
  },
  {
    title: "เรียกรถเข้ารับ",
    icon: <Truck size={20} />,
    href: "/pickup",
    isNew: true,
  },
  {
    title: "เติมเงิน",
    icon: <CreditCard size={20} />,
    href: "/topup",
    submenu: [
      { title: "แจ้งเติมเงิน", href: "/topup" },
      { title: "ประวัติการเติม", href: "/topup/history" },
      { title: "ใบเสร็จรับเงิน/ใบกำกับภาษี", href: "/topup/receipts" },
    ],
  },
  {
    title: "ที่อยู่",
    icon: <MapPin size={20} />,
    href: "/addresses",
    submenu: [
      { title: "ที่อยู่ผู้ส่ง", href: "/addresses/sender" },
      { title: "ที่อยู่ผู้รับ", href: "/addresses/receiver" },
    ],
  },
  {
    title: "รายงาน",
    icon: <FileText size={20} />,
    href: "/reports",
    submenu: [
      { title: "รายงานส่งของ", href: "/reports/shipping" },
      { title: "เก็บเงินปลายทาง", href: "/reports/cod" },
      { title: "รายงานเครดิต", href: "/reports/credit" },
      { title: "รายงานการโอน COD", href: "/reports/withdraw" },
      { title: "รายงานการส่ง SMS", href: "/reports/sms" },
      { title: "ใบกำกับ / ใบเสร็จ COD", href: "/reports/cod-invoice" },
      { title: "รายงานการเช็คสลิป", href: "/reports/slip" },
      { title: "รายงานเร่งจัดส่งพัสดุ", href: "/reports/expedite" },
      { title: "รายงานจัดส่งสำเร็จ", href: "/reports/delivered" },
      { title: "รายงานพัสดุส่งด่วน", href: "/reports/express" },
      { title: "ปฏิทิน COD", href: "/reports/calendar-cod" },
      { title: "ปฏิทินพัสดุ", href: "/reports/calendar-shipment" },
      { title: "รายงานพัสดุไม่เคลื่อนไหว", href: "/reports/inactive-shipment" },
      { title: "รายงานพัสดุมีปัญหา", href: "/reports/problem-shipment" },
    ],
  },
  {
    title: "คลังสินค้า",
    icon: <Warehouse size={20} />,
    href: "/inventory",
    submenu: [
      { title: "รายการสินค้า", href: "/inventory/products" },
      { title: "ประวัติสต๊อกสินค้า", href: "/inventory/stock-history" },
    ],
  },
  {
    title: "ตรวจสอบลูกค้า",
    icon: <Users size={20} />,
    href: "/customer-check",
    isNew: true,
  },
  {
    title: "ใบสั่งซื้อ",
    icon: <Folder size={20} />,
    href: "/orders",
    submenu: [
      { title: "สร้างใบสั่งซื้อ", href: "/orders/create" },
      { title: "รายการสั่งซื้อ", href: "/orders/history" },
      { title: "สรุปยอดขาย", href: "/orders/summary" },
    ],
  },
  {
    title: "ShipChat",
    icon: <MessageCircle size={20} />,
    href: "/shipchat",
    isNew: true,
  },
  {
    title: "ตรวจสอบราคา AI",
    icon: <Box size={20} />,
    href: "/ai-pricing",
    isNew: true,
  },
  {
    title: "Marketplace",
    icon: <ShoppingBag size={20} />,
    href: "/marketplace",
    submenu: [
      { title: "จัดการ คลังสินค้า", href: "/marketplace/products" },
      { title: "จัดการ คำสั่งซื้อ", href: "/marketplace/orders" },
      { title: "ตั้งค่า ระบบ", href: "/marketplace/settings" },
      { title: "เทมเพลตสินค้า", href: "/marketplace/templates" },
    ],
  },
  {
    title: "ShipStore",
    icon: <Briefcase size={20} />,
    href: "/shipstore",
  },
  {
    title: "ตั้งค่ากล่อง",
    icon: <Box size={20} />,
    href: "/box-settings",
  },
  {
    title: "SmartShop",
    icon: <ShoppingBag size={20} />,
    href: "/smartshop",
    submenu: [
      { title: "จัดการ ร้านค้า", href: "/smartshop/shops" },
      { title: "จัดการ คลังสินค้า", href: "/smartshop/products" },
      { title: "จัดการ คำสั่งซื้อ", href: "/smartshop/orders" },
      { title: "กิจกรรม ShipSync x SmartShop", href: "/smartshop/campaigns" },
    ],
  },
  {
    title: "เคลมสินค้า",
    icon: <Gift size={20} />,
    href: "/claims",
    submenu: [
      { title: "สร้างรายการเคลม", href: "/claims/create" },
      { title: "ติดตามสถานะการเคลม", href: "/claims/status" },
      { title: "เงื่อนไขการเคลม", href: "/claims/conditions" },
    ],
  },
  {
    title: "แลกรางวัล",
    icon: <Gift size={20} />,
    href: "/rewards",
  },
  {
    title: "ตารางราคา",
    icon: <List size={20} />,
    href: "/pricing",
    isNew: true,
  },
  {
    title: "เงื่อนไขการใช้งาน",
    icon: <Info size={20} />,
    href: "/terms",
  },
  {
    title: "คู่มือการใช้งาน",
    icon: <BookOpen size={20} />,
    href: "/manual",
  },
  {
    title: "ติดต่อแอดมิน",
    icon: <Headphones size={20} />,
    href: "/contact",
  },
  {
    title: "เขียนข้อเสนอแนะ",
    icon: <Edit size={20} />,
    href: "/feedback",
    isNew: true,
  },
];

interface SidebarProps {
  isOpen: boolean;
}

export default function Sidebar({ isOpen }: SidebarProps) {
  const pathname = usePathname();

  // คุณสามารถเพิ่มตรรกะเพื่อกำหนดว่า submenu ไหนควรเปิด
  const [openSubmenus, setOpenSubmenus] = useState<Record<string, boolean>>({});

  const toggleSubmenu = (title: string) => {
    setOpenSubmenus(prev => ({
      ...prev,
      [title]: !prev[title]
    }));
  };

  return (
    <aside className={cn(
      "bg-white text-slate-800 flex flex-col border-r transition-all duration-300 ease-in-out h-screen overflow-hidden",
      isOpen ? "w-64" : "w-20"
    )}>
      {/* Logo */}
      <div className="p-4 flex items-center justify-center h-16 border-b">
        {isOpen ? (
          <h1 className="text-2xl font-bold text-blue-600 flex items-center">
            <Box className="mr-2" /> ShipSync
          </h1>
        ) : (
          <Box className="text-blue-600" size={24} />
        )}
      </div>

      {/* Menu */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-2">
          {mainMenuItems.map((item) => (
            <li key={item.title}>
              {item.submenu ? (
                <div className="mb-1">
                  <button
                    onClick={() => toggleSubmenu(item.title)}
                    className={cn(
                      "flex items-center w-full rounded-md p-2 text-sm font-medium transition-colors hover:bg-slate-100 hover:text-blue-600",
                      pathname.startsWith(item.href) ? "bg-blue-50 text-blue-600" : ""
                    )}
                  >
                    <span className="flex items-center">
                      <span className={cn("mr-2", !isOpen && "mr-0")}>{item.icon}</span>
                      {isOpen && <span>{item.title}</span>}
                    </span>
                    {isOpen && item.isNew && (
                      <span className="ml-auto bg-green-500 text-white text-xs px-1.5 py-0.5 rounded">
                        NEW
                      </span>
                    )}
                    {isOpen && (
                      <svg
                        className={cn(
                          "ml-auto h-4 w-4 transition-transform",
                          openSubmenus[item.title] ? "rotate-180" : ""
                        )}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M19 9l-7 7-7-7"
                        />
                      </svg>
                    )}
                  </button>
                  {isOpen && openSubmenus[item.title] && (
                    <ul className="mt-1 space-y-1 px-6">
                      {item.submenu.map((subitem) => (
                        <li key={subitem.title}>
                          <Link
                            href={subitem.href}
                            className={cn(
                              "block rounded-md p-2 text-sm transition-colors hover:bg-slate-100 hover:text-blue-600",
                              pathname === subitem.href ? "bg-blue-50 text-blue-600" : ""
                            )}
                          >
                            {subitem.title}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ) : (
                <Link
                  href={item.href}
                  className={cn(
                    "flex items-center rounded-md p-2 text-sm font-medium transition-colors hover:bg-slate-100 hover:text-blue-600",
                    pathname === item.href ? "bg-blue-50 text-blue-600" : ""
                  )}
                >
                  <span className={cn("mr-2", !isOpen && "mr-0")}>{item.icon}</span>
                  {isOpen && <span>{item.title}</span>}
                  {isOpen && item.isNew && (
                    <span className="ml-auto bg-green-500 text-white text-xs px-1.5 py-0.5 rounded">
                      NEW
                    </span>
                  )}
                </Link>
              )}
            </li>
          ))}
        </ul>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t">
        <Link
          href="/settings"
          className="flex items-center rounded-md p-2 text-sm font-medium transition-colors hover:bg-slate-100 hover:text-blue-600"
        >
          <Settings size={20} className="mr-2" />
          {isOpen && <span>ตั้งค่าระบบ</span>}
        </Link>
      </div>
    </aside>
  );
}
